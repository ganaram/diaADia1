<?php
    require_once 'setup.php';
    require_once 'database/conexion.php';
    require_once 'includes/header.php';
    ?>

    <!-- Body -->


    <!-- End Body -->

<?php 
    require_once 'includes/footer.php';
?>